How to run the HashBreaker tool:

1. Make sure you have Python 3 installed.
2. Install dependencies using:
   pip install flask hashid requests

3. Run the app:
   python app.py

4. Open your browser and go to:
   http://127.0.0.1:5000/

Username: admin
Password: kader11000

Tool by kader11000
