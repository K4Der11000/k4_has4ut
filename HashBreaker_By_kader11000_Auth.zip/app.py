from flask import Flask, render_template, request, make_response, Response
from hashid import HashID
import requests
import os
from functools import wraps

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
hashid = HashID()
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

USERNAME = "admin"
PASSWORD = "kader11000"

def check_auth(username, password):
    return username == USERNAME and password == PASSWORD

def authenticate():
    return Response('Authentication required.', 401, {'WWW-Authenticate': 'Basic realm="Login Required"'})

def requires_auth(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        auth = request.authorization
        if not auth or not check_auth(auth.username, auth.password):
            return authenticate()
        return f(*args, **kwargs)
    return decorated

def detect_hash_type(hash_input):
    results = hashid.identify(hash_input)
    return results[0] if results else "Unknown"

def crack_hash_online(hash_value):
    try:
        url = "https://hashes.com/en/decrypt/hash"
        headers = {"User-Agent": "Mozilla/5.0"}
        data = {"hashes": hash_value}
        r = requests.post(url, headers=headers, data=data)
        if "result-table" in r.text and "col-md-6" in r.text:
            return "Decrypted (found online)"
        else:
            return "Not found online"
    except Exception:
        return "Failed to connect"

last_results = []

@app.route("/", methods=["GET", "POST"])
@requires_auth
def index():
    global last_results
    results = []
    hash_input = None

    if request.method == "POST":
        if 'hash_input' in request.form:
            hash_input = request.form.get("hash_input")
            result = detect_hash_type(hash_input)
            cracked = crack_hash_online(hash_input)
            results.append({"hash": hash_input, "type": result, "cracked": cracked})

        elif 'hash_file' in request.files:
            file = request.files['hash_file']
            if file.filename.endswith(".txt"):
                lines = file.read().decode().splitlines()
                for h in lines:
                    h = h.strip()
                    if h:
                        results.append({
                            "hash": h,
                            "type": detect_hash_type(h),
                            "cracked": crack_hash_online(h)
                        })

        elif 'fetch_online' in request.form:
            try:
                source_url = "https://raw.githubusercontent.com/danielmiessler/SecLists/master/Passwords/Leaked-Databases/rockyou.txt"
                r = requests.get(source_url)
                sample = r.text.splitlines()[:5]
                import hashlib
                for password in sample:
                    hashed = hashlib.md5(password.encode()).hexdigest()
                    results.append({
                        "hash": hashed,
                        "type": detect_hash_type(hashed),
                        "cracked": crack_hash_online(hashed)
                    })
            except Exception:
                results.append({"hash": "N/A", "type": "Error", "cracked": "Failed to load data"})

        last_results = results

    return render_template("index.html", results=results, hash_input=hash_input)

@app.route("/view_results", methods=["POST"])
@requires_auth
def view_results():
    global last_results
    return render_template("results.html", results=last_results)

@app.route("/download_results", methods=["POST"])
@requires_auth
def download_results():
    global last_results
    html_content = render_template("results.html", results=last_results)
    response = make_response(html_content)
    response.headers["Content-Disposition"] = "attachment; filename=hash_results.html"
    response.headers["Content-Type"] = "text/html"
    return response

if __name__ == "__main__":
    app.run(debug=True)
